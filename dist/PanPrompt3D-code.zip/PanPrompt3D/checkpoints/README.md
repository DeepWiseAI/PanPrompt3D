# Full-model checkpoints

The binary weights live in this directory on the prepared shared-folder copy.
They are excluded from the code-only archive and ordinary Git history.

| File | Purpose |
| --- | --- |
| `panprompt3d_full_best.pth` | Full merged PanPrompt3D with CF loss enabled; training-Dice-selected checkpoint, saved epoch counter 192. |
| `panprompt3d_full_last.pth` | Same full-model training run's last saved model; epoch counter is recorded in the manifest. |
| `initialization_water.pth` | Prior Water-trained initialization used by the full merged run. Not a separate experiment result. |
| `panprompt3d_resume_last.pth` | Sanitized optimizer/scheduler resume payload for the same full run. Keep local; not a public model release asset. |

The first three files are tensor-only state dictionaries, preserving the original
model values exactly. They contain no training arguments, patient IDs, dataset
paths, or environment locations. `manifest.json` records SHA-256, byte size, source
checksum and the safe training configuration. The initialization model has extra
legacy keys; partial loading is intentional for initialization only.

Model-only files load with `torch.load(..., weights_only=True)`. The sanitized
resume payload also omits original argument objects and dataset lists; preserve
it locally when optimizer-state continuation is needed. Its original run's data
and GPU setup must be supplied privately by the user, never published here.

The code-only archive does not contain these binaries. No download URL is invented:
assign an approved release-asset location when you publish the repository.
